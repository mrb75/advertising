from celery import shared_task
from users.models import Notification
from django.utils import timezone
from datetime import timedelta


@shared_task(name='change_ban_status')
def change_ban_status(users):
    users.update(date_banned=None)
    # for user in users:
    #     user.date_banned = None
    #     user.save()
